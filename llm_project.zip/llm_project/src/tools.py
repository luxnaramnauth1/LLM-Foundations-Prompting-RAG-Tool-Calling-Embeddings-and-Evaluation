"""Function (tool) calling: schemas, a registry with validation, safe execution, and a tool loop.

The model only proposes calls. Your code validates arguments, runs the function,
and returns a structured result. The model never executes anything itself.
"""
from __future__ import annotations

import ast
import json
import operator
from dataclasses import dataclass
from typing import Any, Callable

# ---------- a safe arithmetic evaluator (no eval) ----------

_BIN_OPS = {ast.Add: operator.add, ast.Sub: operator.sub,
            ast.Mult: operator.mul, ast.Div: operator.truediv}
_UNARY_OPS = {ast.USub: operator.neg}


def safe_eval(expr: str) -> float:
    """Evaluate numbers with + - * / and parentheses. Anything else is rejected."""

    def _ev(node: ast.AST) -> float:
        if isinstance(node, ast.Expression):
            return _ev(node.body)
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)) \
                and not isinstance(node.value, bool):
            return node.value
        if isinstance(node, ast.BinOp) and type(node.op) in _BIN_OPS:
            return _BIN_OPS[type(node.op)](_ev(node.left), _ev(node.right))
        if isinstance(node, ast.UnaryOp) and type(node.op) in _UNARY_OPS:
            return _UNARY_OPS[type(node.op)](_ev(node.operand))
        raise ValueError(f"unsupported expression element: {type(node).__name__}")

    return _ev(ast.parse(expr, mode="eval"))


# ---------- example tool implementations ----------

_FAKE_WEATHER = {
    "paris": "18 C, cloudy",
    "port louis": "27 C, sunny",
    "london": "12 C, light rain",
}


def get_weather(city: str) -> dict[str, str]:
    return {"city": city, "forecast": _FAKE_WEATHER.get(city.lower(), "no data available")}


# ---------- registry ----------

@dataclass
class Tool:
    name: str
    description: str
    parameters: dict[str, Any]          # JSON Schema object describing the arguments
    fn: Callable[..., Any]

    def schema(self) -> dict[str, Any]:
        return {"type": "function",
                "function": {"name": self.name, "description": self.description,
                             "parameters": self.parameters}}


class ToolRegistry:
    def __init__(self) -> None:
        self._tools: dict[str, Tool] = {}

    def register(self, tool: Tool) -> Tool:
        if tool.name in self._tools:
            raise ValueError(f"tool {tool.name!r} already registered")
        self._tools[tool.name] = tool
        return tool

    def schemas(self) -> list[dict[str, Any]]:
        return [t.schema() for t in self._tools.values()]

    def dispatch(self, name: str, arguments_json: str) -> str:
        """Validate and run a tool call. Always returns a JSON string, including errors."""
        if name not in self._tools:
            return json.dumps({"error": f"unknown tool {name!r}"})
        try:
            args = json.loads(arguments_json or "{}")
        except json.JSONDecodeError as e:
            return json.dumps({"error": f"invalid JSON arguments: {e}"})
        if not isinstance(args, dict):
            return json.dumps({"error": "arguments must be a JSON object"})

        tool = self._tools[name]
        schema = tool.parameters
        missing = [r for r in schema.get("required", []) if r not in args]
        if missing:
            return json.dumps({"error": f"missing arguments: {missing}"})
        unexpected = sorted(set(args) - set(schema.get("properties", {})))
        if unexpected:
            return json.dumps({"error": f"unexpected arguments: {unexpected}"})

        try:
            result = tool.fn(**args)
        except Exception as e:  # report failures to the model in a structured way
            return json.dumps({"error": f"{type(e).__name__}: {e}"})
        return json.dumps(result)


def default_registry() -> ToolRegistry:
    registry = ToolRegistry()
    registry.register(Tool(
        name="get_weather",
        description="Get the current weather forecast for a city.",
        parameters={"type": "object",
                    "properties": {"city": {"type": "string", "description": "City name"}},
                    "required": ["city"]},
        fn=get_weather,
    ))
    registry.register(Tool(
        name="calculator",
        description="Evaluate an arithmetic expression using + - * / and parentheses.",
        parameters={"type": "object",
                    "properties": {"expression": {"type": "string"}},
                    "required": ["expression"]},
        fn=lambda expression: {"result": safe_eval(expression)},
    ))
    return registry


# ---------- the tool loop ----------

def run_tool_loop(llm: Any, registry: ToolRegistry, user_message: str,
                  system: str = "You are a helpful assistant. Use tools when they help.",
                  max_steps: int = 4) -> dict[str, Any]:
    messages: list[dict[str, Any]] = [
        {"role": "system", "content": system},
        {"role": "user", "content": user_message},
    ]
    trace: list[dict[str, Any]] = []
    for _ in range(max_steps):
        response = llm.chat(messages, tools=registry.schemas())
        if not response.tool_calls:
            return {"answer": response.content, "trace": trace, "messages": messages}

        messages.append({
            "role": "assistant",
            "content": None,
            "tool_calls": [{"id": c["id"], "type": "function",
                            "function": {"name": c["name"], "arguments": c["arguments"]}}
                           for c in response.tool_calls],
        })
        for call in response.tool_calls:
            result = registry.dispatch(call["name"], call["arguments"])
            trace.append({"tool": call["name"], "arguments": call["arguments"], "result": result})
            messages.append({"role": "tool", "tool_call_id": call["id"], "content": result})

    return {"answer": None, "trace": trace, "messages": messages,
            "error": f"stopped after {max_steps} steps"}

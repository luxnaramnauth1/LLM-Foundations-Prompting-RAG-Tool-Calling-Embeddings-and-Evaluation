"""Text embeddings.

hashed_embedding is an offline, lexical embedding (unigrams + bigrams hashed
into a fixed-size vector). It rewards shared words but knows nothing about
meaning, so synonyms do not match. It exists so notebooks run without a key.

OpenAIEmbedder returns semantic embeddings. Select with EMBED_PROVIDER:
    hash    (default)
    openai  (needs `pip install openai`, OPENAI_API_KEY, optional EMBED_MODEL)
"""
from __future__ import annotations

import hashlib
import math
import os
from typing import Callable

from llm_utils import content_tokens


def _normalize(vec: list[float]) -> list[float]:
    norm = math.sqrt(sum(x * x for x in vec))
    return [x / norm for x in vec] if norm else vec


def hashed_embedding(text: str, dim: int = 256) -> list[float]:
    tokens = content_tokens(text)  # stopwords add noise to lexical vectors
    features = tokens + [f"{a}_{b}" for a, b in zip(tokens, tokens[1:])]
    vec = [0.0] * dim
    for feat in features:
        h = int(hashlib.md5(feat.encode("utf-8")).hexdigest(), 16)
        idx = h % dim
        sign = 1.0 if (h >> 100) & 1 else -1.0
        vec[idx] += sign
    return _normalize(vec)


def cosine(a: list[float], b: list[float]) -> float:
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(x * x for x in b))
    if not na or not nb:
        return 0.0
    return sum(x * y for x, y in zip(a, b)) / (na * nb)


class OpenAIEmbedder:
    def __init__(self, model: str | None = None) -> None:
        from openai import OpenAI  # imported lazily

        self.client = OpenAI()
        self.model = model or os.getenv("EMBED_MODEL", "text-embedding-3-small")

    def __call__(self, text: str) -> list[float]:
        return self.client.embeddings.create(model=self.model, input=text).data[0].embedding


def get_embedder() -> Callable[[str], list[float]]:
    provider = os.getenv("EMBED_PROVIDER", "hash").lower()
    if provider == "hash":
        return hashed_embedding
    if provider == "openai":
        return OpenAIEmbedder()
    raise ValueError(f"Unknown EMBED_PROVIDER {provider!r}; use 'hash' or 'openai'")

"""Shared sample corpus and evaluation cases used by the RAG and evaluation notebooks."""

DOCS = {
    "refund_policy": (
        "Customers can request a full refund within 30 days of purchase. Refunds require "
        "the original receipt and are processed to the original payment method within "
        "5 business days. Digital products are not refundable once downloaded."
    ),
    "shipping": (
        "Standard shipping takes 3 to 5 business days within the country. Express shipping "
        "takes 1 to 2 business days and costs an extra fee. Orders placed after 2 pm are "
        "dispatched the next business day."
    ),
    "warranty": (
        "All hardware products carry a one year limited warranty against manufacturing "
        "defects. The warranty does not cover accidental damage, water damage, or normal "
        "wear. Warranty claims require proof of purchase."
    ),
    "support": (
        "Customer support is available by email and by phone. Phone support runs Monday "
        "to Friday from 9 am to 5 pm. Email requests receive a reply within one business day."
    ),
}

# Each case: question, keyword phrases the answer should contain, the document that
# should be retrieved (None if the question is outside the corpus), and whether the
# system should abstain.
QA_CASES = [
    {"id": "qa-001", "question": "How long do refunds take?",
     "keywords": ["5 business days"], "relevant_doc": "refund_policy", "expect_abstain": False},
    {"id": "qa-002", "question": "How fast is express shipping?",
     "keywords": ["1 to 2 business days"], "relevant_doc": "shipping", "expect_abstain": False},
    {"id": "qa-003", "question": "What does the warranty cover?",
     "keywords": ["manufacturing defects"], "relevant_doc": "warranty", "expect_abstain": False},
    {"id": "qa-004", "question": "When can I call support by phone?",
     "keywords": ["9 am to 5 pm"], "relevant_doc": "support", "expect_abstain": False},
    {"id": "qa-005", "question": "Do you sell furniture?",
     "keywords": [], "relevant_doc": None, "expect_abstain": True},
]

GOLD_RETRIEVAL = [(c["question"], c["relevant_doc"]) for c in QA_CASES if c["relevant_doc"]]

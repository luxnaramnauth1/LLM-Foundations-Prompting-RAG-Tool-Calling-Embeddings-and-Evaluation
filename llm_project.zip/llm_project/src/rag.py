"""Retrieval-augmented generation: chunk, embed, index, retrieve, then answer with citations."""
from __future__ import annotations

from typing import Any, Callable, Optional

from vector_store import InMemoryVectorStore

SYSTEM_PROMPT = (
    "Answer the question using only the context provided. "
    "If the context does not contain the answer, say you don't know. "
    "Cite the source id in square brackets after each claim."
)


def chunk_text(text: str, max_words: int = 40, overlap: int = 10) -> list[str]:
    """Split text into overlapping word windows."""
    if max_words <= overlap:
        raise ValueError("max_words must be larger than overlap")
    words = text.split()
    step = max_words - overlap
    chunks: list[str] = []
    i = 0
    while i < len(words):
        chunks.append(" ".join(words[i:i + max_words]))
        if i + max_words >= len(words):
            break
        i += step
    return chunks


class RAGPipeline:
    def __init__(self, llm: Any, embed_fn: Callable[[str], list[float]],
                 store: Optional[InMemoryVectorStore] = None,
                 k: int = 3, max_words: int = 40, overlap: int = 10) -> None:
        self.llm = llm
        self.embed = embed_fn
        self.store = store or InMemoryVectorStore()
        self.k = k
        self.max_words = max_words
        self.overlap = overlap

    def index(self, docs: dict[str, str]) -> int:
        """Index documents keyed by doc_id. Returns the number of chunks stored."""
        count = 0
        for doc_id, text in docs.items():
            for j, chunk in enumerate(chunk_text(text, self.max_words, self.overlap)):
                self.store.add(f"{doc_id}#{j}", chunk, self.embed(chunk), {"doc_id": doc_id})
                count += 1
        return count

    def retrieve(self, question: str, k: Optional[int] = None) -> list[dict[str, Any]]:
        return self.store.search(self.embed(question), k=k or self.k)

    def answer(self, question: str, k: Optional[int] = None) -> dict[str, Any]:
        hits = self.retrieve(question, k)
        context = "\n".join(f"[{h['id']}] {h['text']}" for h in hits)
        messages = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": f"Context:\n{context}\n\nQuestion: {question}"},
        ]
        response = self.llm.chat(messages)
        return {
            "answer": response.content,
            "sources": [h["id"] for h in hits],
            "scores": [h["score"] for h in hits],
            "context": context,
            "messages": messages,
        }

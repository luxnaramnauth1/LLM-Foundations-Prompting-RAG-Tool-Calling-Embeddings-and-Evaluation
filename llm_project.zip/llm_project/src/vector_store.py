"""A small in-memory vector store with cosine search, metadata filters, and JSON persistence.

Good for teaching and small corpora. For large data, use a dedicated index
(FAISS, Chroma, pgvector, or a managed vector database) with the same interface ideas.
"""
from __future__ import annotations

import json
from typing import Any, Optional

from embeddings import cosine


class InMemoryVectorStore:
    def __init__(self) -> None:
        self._ids: list[str] = []
        self._id_set: set[str] = set()
        self._texts: list[str] = []
        self._vectors: list[list[float]] = []
        self._meta: list[dict[str, Any]] = []

    def __len__(self) -> int:
        return len(self._ids)

    def add(self, id: str, text: str, vector: list[float], metadata: Optional[dict] = None) -> None:
        if id in self._id_set:
            raise ValueError(f"duplicate id {id!r}")
        self._id_set.add(id)
        self._ids.append(id)
        self._texts.append(text)
        self._vectors.append(vector)
        self._meta.append(metadata or {})

    def search(self, query_vector: list[float], k: int = 3,
               where: Optional[dict[str, Any]] = None) -> list[dict[str, Any]]:
        scored = []
        for i, vec in enumerate(self._vectors):
            if where and any(self._meta[i].get(key) != val for key, val in where.items()):
                continue
            scored.append((cosine(query_vector, vec), i))
        scored.sort(key=lambda pair: -pair[0])
        return [
            {"id": self._ids[i], "text": self._texts[i],
             "score": round(score, 4), "metadata": self._meta[i]}
            for score, i in scored[:k]
        ]

    def save(self, path: str) -> None:
        payload = {"ids": self._ids, "texts": self._texts,
                   "vectors": self._vectors, "metadata": self._meta}
        with open(path, "w", encoding="utf-8") as f:
            json.dump(payload, f)

    @classmethod
    def load(cls, path: str) -> "InMemoryVectorStore":
        with open(path, encoding="utf-8") as f:
            payload = json.load(f)
        store = cls()
        for id_, text, vec, meta in zip(payload["ids"], payload["texts"],
                                        payload["vectors"], payload["metadata"]):
            store.add(id_, text, vec, meta)
        return store

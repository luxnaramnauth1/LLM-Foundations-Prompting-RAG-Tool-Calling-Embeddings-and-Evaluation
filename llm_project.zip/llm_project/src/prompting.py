"""Prompt construction helpers: templates with checked variables, few-shot messages, output parsing."""
from __future__ import annotations

import json
import re
import string
from typing import Any, Optional


class PromptTemplate:
    """A str.format-style template that refuses missing or unused variables."""

    def __init__(self, template: str) -> None:
        self.template = template
        self.variables = sorted({name for _, name, _, _ in string.Formatter().parse(template) if name})

    def render(self, **kwargs: Any) -> str:
        missing = [v for v in self.variables if v not in kwargs]
        if missing:
            raise KeyError(f"missing template variables: {missing}")
        unused = sorted(set(kwargs) - set(self.variables))
        if unused:
            raise KeyError(f"unused template variables: {unused}")
        return self.template.format(**kwargs)


def few_shot_messages(system: str, examples: list[dict[str, str]], query: str) -> list[dict[str, str]]:
    """Build a chat history: system prompt, example input/output pairs, then the real query."""
    messages: list[dict[str, str]] = [{"role": "system", "content": system}]
    for ex in examples:
        messages.append({"role": "user", "content": ex["input"]})
        messages.append({"role": "assistant", "content": ex["output"]})
    messages.append({"role": "user", "content": query})
    return messages


def parse_json_output(text: str) -> tuple[Optional[Any], Optional[str]]:
    """Parse a model reply that should be JSON. Tolerates a surrounding ```json fence.

    Returns (object, None) on success or (None, error_message) on failure.
    """
    cleaned = re.sub(r"^```(?:json)?\s*|\s*```$", "", (text or "").strip())
    try:
        return json.loads(cleaned), None
    except json.JSONDecodeError as e:
        return None, str(e)


def validate_keys(obj: Any, required: list[str]) -> list[str]:
    """Return the required keys that are missing from a parsed object."""
    if not isinstance(obj, dict):
        return list(required)
    return [k for k in required if k not in obj]

"""Evaluation building blocks: text metrics, retrieval metrics, a groundedness heuristic, and a runner.

The runner is framework-free on purpose. Frameworks such as Ragas, DeepEval,
promptfoo, and TruLens provide similar pieces with more metrics and reporting.
"""
from __future__ import annotations

import re
from statistics import mean
from typing import Any, Callable, Optional

from llm_utils import content_tokens, tokenize


def normalize(text: str) -> str:
    return " ".join(re.findall(r"[a-z0-9']+", (text or "").lower()))


def exact_match(prediction: str, reference: str) -> bool:
    return normalize(prediction) == normalize(reference)


def keyword_recall(prediction: str, keywords: list[str]) -> float:
    """Share of keyword phrases whose words all appear in the prediction. Empty list gives 1.0."""
    if not keywords:
        return 1.0
    pred_tokens = set(tokenize(prediction))
    hits = sum(1 for phrase in keywords if all(t in pred_tokens for t in tokenize(phrase)))
    return hits / len(keywords)


def retrieval_metrics(ranked_ids: list[str], relevant_ids: list[str], k: int) -> dict[str, float]:
    relevant = set(relevant_ids)
    top = ranked_ids[:k]
    hits = {i for i in top if i in relevant}
    recall = len(hits) / len(relevant) if relevant else 0.0
    precision = len([i for i in top if i in relevant]) / k if k else 0.0
    mrr = 0.0
    for rank, item in enumerate(ranked_ids, start=1):
        if item in relevant:
            mrr = 1.0 / rank
            break
    return {"recall@k": round(recall, 3), "precision@k": round(precision, 3), "mrr": round(mrr, 3)}


def doc_ids_from_chunks(chunk_ids: list[str]) -> list[str]:
    """Collapse chunk ids like 'doc#2' to document ids, keeping first-seen order."""
    return list(dict.fromkeys(c.split("#")[0] for c in chunk_ids))


def groundedness(answer: str, context: str) -> float:
    """Heuristic: share of the answer's content words that appear in the context.

    It catches gross invention but misses subtle errors and rewards copying.
    Use it as a smoke test, and validate a model-graded judge against human labels.
    """
    answer_terms = content_tokens(answer)
    if not answer_terms:
        return 0.0
    context_terms = set(tokenize(context))
    return sum(1 for t in answer_terms if t in context_terms) / len(answer_terms)


def score_from_judge(text: str) -> Optional[int]:
    """Pull the first 1-5 integer from a judge reply. Returns None if there is none."""
    m = re.search(r"\b([1-5])\b", text or "")
    return int(m.group(1)) if m else None


def run_eval(cases: list[dict[str, Any]],
             system: Callable[[str], dict[str, Any]],
             metrics: dict[str, Callable[[dict, dict], Optional[float]]]) -> dict[str, Any]:
    """Run every case through the system and score it.

    A metric may return None for cases it does not apply to. Those are excluded from its mean.
    """
    rows = []
    for case in cases:
        result = system(case["question"])
        row: dict[str, Any] = {"id": case["id"]}
        for name, fn in metrics.items():
            row[name] = fn(case, result)
        rows.append(row)

    summary: dict[str, Optional[float]] = {}
    for name in metrics:
        values = [r[name] for r in rows if r[name] is not None]
        summary[name] = round(mean(values), 3) if values else None
    return {"rows": rows, "summary": summary}

"""Chat model clients, including an offline mock used by the notebooks.

MockLLM follows fixed rules. Its answers are NOT representative of real model
behaviour: use it to test plumbing (prompts, retrieval, tool loops, parsing),
then switch to a real provider to measure quality.

Select a provider with the LLM_PROVIDER environment variable:
    mock    (default; no API key, no extra packages)
    openai  (needs `pip install openai`, OPENAI_API_KEY, optional LLM_MODEL)
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from typing import Any, Optional

TOKEN_RE = re.compile(r"[a-z0-9']+")
STOPWORDS = {
    "the", "a", "an", "of", "to", "in", "is", "are", "was", "and", "or", "for",
    "on", "at", "by", "with", "what", "which", "who", "how", "does", "do", "it",
    "this", "that", "be", "from", "as", "when", "can", "i", "you", "your",
}
POSITIVE = {"good", "great", "excellent", "love", "happy", "fantastic", "reliable", "fast", "helpful"}
NEGATIVE = {"bad", "poor", "terrible", "hate", "slow", "broken", "awful", "disappointing", "unreliable"}


def tokenize(text: str) -> list[str]:
    return TOKEN_RE.findall(text.lower())


def content_tokens(text: str) -> list[str]:
    return [t for t in tokenize(text) if t not in STOPWORDS]


@dataclass
class ChatResponse:
    content: Optional[str] = None
    # Each call: {"id": str, "name": str, "arguments": <JSON string>}
    tool_calls: list[dict[str, Any]] = field(default_factory=list)


class MockLLM:
    """Deterministic stand-in for a chat model, driven by simple rules."""

    name = "mock"

    def __init__(self) -> None:
        self.calls = 0

    def chat(self, messages: list[dict[str, Any]], tools: Optional[list[dict]] = None) -> ChatResponse:
        self.calls += 1
        last = messages[-1]
        # After a tool result, summarise it.
        if last["role"] == "tool":
            return ChatResponse(content=f"The tool returned: {last['content']}")

        system = " ".join(m.get("content") or "" for m in messages if m["role"] == "system").lower()
        user = next((m["content"] for m in reversed(messages) if m["role"] == "user"), "")

        if tools:
            call = self._pick_tool(user, tools)
            if call:
                return ChatResponse(tool_calls=[call])

        if "Context:" in user and "Question:" in user:
            return ChatResponse(content=self._answer_from_context(user))

        if "sentiment" in system or "sentiment" in user.lower():
            return ChatResponse(content=json.dumps({"sentiment": self._sentiment(user)}))

        return ChatResponse(content="I don't have enough information to answer that.")

    def _pick_tool(self, user: str, tools: list[dict]) -> Optional[dict[str, Any]]:
        names = {t["function"]["name"] for t in tools}
        if "get_weather" in names and "weather" in user.lower():
            m = re.search(r"\b(?:in|for)\s+([A-Z][\w\s-]*)", user)
            city = m.group(1).strip() if m else "Paris"
            return {"id": f"call_{self.calls}", "name": "get_weather",
                    "arguments": json.dumps({"city": city})}
        if "calculator" in names:
            m = re.search(r"[\d(][\d\s.+\-*/()]*[\d)]", user)
            if m and re.search(r"[+\-*/]", m.group(0)):
                return {"id": f"call_{self.calls}", "name": "calculator",
                        "arguments": json.dumps({"expression": m.group(0).strip()})}
        return None

    def _answer_from_context(self, user: str) -> str:
        context = user.split("Context:", 1)[1].split("Question:", 1)[0]
        question = user.split("Question:", 1)[1]
        q_tokens = set(content_tokens(question))
        best: Optional[tuple[str, str]] = None
        best_overlap = 0
        for line in context.splitlines():
            m = re.match(r"\[([^\]]+)\]\s*(.*)", line.strip())
            if not m:
                continue
            overlap = len(q_tokens & set(content_tokens(m.group(2))))
            if overlap > best_overlap:
                best, best_overlap = (m.group(1), m.group(2)), overlap
        if best is None:
            return "I don't know based on the provided context."
        return f"{best[1]} [{best[0]}]"

    def _sentiment(self, user: str) -> str:
        text = user.split("Text:")[-1]
        toks = set(tokenize(text))
        pos, neg = len(toks & POSITIVE), len(toks & NEGATIVE)
        if pos > neg:
            return "positive"
        if neg > pos:
            return "negative"
        return "neutral"


class OpenAIChat:
    """Thin wrapper around the OpenAI chat completions API."""

    name = "openai"

    def __init__(self, model: Optional[str] = None) -> None:
        from openai import OpenAI  # imported lazily so the mock needs no packages

        self.client = OpenAI()
        self.model = model or os.getenv("LLM_MODEL", "gpt-4o-mini")

    def chat(self, messages: list[dict[str, Any]], tools: Optional[list[dict]] = None) -> ChatResponse:
        kwargs: dict[str, Any] = {"model": self.model, "messages": messages}
        if tools:
            kwargs["tools"] = tools
        msg = self.client.chat.completions.create(**kwargs).choices[0].message
        calls = [
            {"id": tc.id, "name": tc.function.name, "arguments": tc.function.arguments}
            for tc in (msg.tool_calls or [])
        ]
        return ChatResponse(content=msg.content, tool_calls=calls)


def get_llm(provider: Optional[str] = None):
    provider = (provider or os.getenv("LLM_PROVIDER", "mock")).lower()
    if provider == "mock":
        return MockLLM()
    if provider == "openai":
        return OpenAIChat()
    raise ValueError(f"Unknown LLM_PROVIDER {provider!r}; use 'mock' or 'openai'")

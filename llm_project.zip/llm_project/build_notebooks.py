#!/usr/bin/env python3
"""Generate the Jupyter notebooks in notebooks/ as nbformat 4 JSON.

Keeping notebook sources in Python makes them easy to review and diff.
Run:  python3 build_notebooks.py
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "notebooks"

SETUP = '''
import sys, pathlib
ROOT = pathlib.Path.cwd()
if ROOT.name == "notebooks":
    ROOT = ROOT.parent
sys.path.insert(0, str(ROOT / "src"))
'''


def _lines(text):
    text = text.strip("\n")
    parts = text.split("\n")
    return [p + "\n" for p in parts[:-1]] + [parts[-1]]


def md(text):
    return {"cell_type": "markdown", "metadata": {}, "source": _lines(text)}


def code(text):
    return {"cell_type": "code", "execution_count": None, "metadata": {},
            "outputs": [], "source": _lines(text)}


def notebook(cells):
    return {
        "cells": cells,
        "metadata": {
            "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
            "language_info": {"name": "python"},
        },
        "nbformat": 4,
        "nbformat_minor": 4,
    }


# ---------------------------------------------------------------- 01
PROMPT_ENGINEERING = [
    md("""
# 01 · Prompt engineering

This notebook covers:

1. Prompt templates whose variables are checked before rendering
2. Zero-shot versus few-shot message construction
3. Structured (JSON) output, parsed and validated
4. Comparing prompt versions against labelled examples

By default the notebook uses an offline mock model. Set `LLM_PROVIDER=openai` and
`OPENAI_API_KEY` to run the same code against a real model. The mock's answers do
not depend on wording, so the comparison in section 4 only shows the workflow.
"""),
    code(SETUP + '''
from llm_utils import get_llm
from prompting import PromptTemplate, few_shot_messages, parse_json_output, validate_keys

llm = get_llm()
print("Provider:", llm.name)
'''),
    md("## 1. Prompt templates with checked variables"),
    code('''
template = PromptTemplate(
    "You are a {role}. Answer in at most {max_sentences} sentences.\\n"
    "Question: {question}"
)
print("Variables:", template.variables)
print(template.render(role="support agent", max_sentences=2,
                      question="How do I reset my password?"))

try:
    template.render(role="support agent", question="How do I reset my password?")
except KeyError as e:
    print("Caught:", e)
'''),
    md("## 2. Zero-shot versus few-shot messages"),
    code('''
examples = [
    {"input": "Text: The delivery was fast and the box was intact.",
     "output": '{"sentiment": "positive"}'},
    {"input": "Text: The app crashes every time I open it.",
     "output": '{"sentiment": "negative"}'},
]
system = ('Classify the sentiment of the text. '
          'Respond only with JSON: {"sentiment": "positive" | "negative" | "neutral"}')

messages = few_shot_messages(system, examples, "Text: Support never answered my email.")
for m in messages:
    print(f"{m['role']:>9}: {m['content']}")
'''),
    md("## 3. Structured output: parse and validate"),
    code('''
query = "Text: The new update is great and very reliable."
response = llm.chat(few_shot_messages(system, examples, query))
print("Raw reply:", response.content)

obj, err = parse_json_output(response.content)
print("Parsed:", obj, "| error:", err)
if obj is not None:
    print("Missing keys:", validate_keys(obj, ["sentiment"]))

# Failure handling: prose instead of JSON should be caught, not silently accepted.
obj, err = parse_json_output("Sure! The sentiment is positive.")
print("Bad output ->", obj, "| error:", err)
'''),
    md("""
## 4. Comparing prompt versions on labelled examples

Change a prompt, measure on a fixed labelled set, and keep the version that scores
best without breaking the cases you already handle.
"""),
    code('''
labelled = [
    ("I love this phone, the battery is excellent.", "positive"),
    ("Terrible customer service, very slow replies.", "negative"),
    ("The package arrived on Tuesday.", "neutral"),
    ("Helpful staff and fast delivery, great experience.", "positive"),
]

prompt_versions = {
    "v1_terse": 'Classify sentiment as JSON: {"sentiment": ...}',
    "v2_detailed": ('You classify customer sentiment. Choose exactly one label: positive, '
                    'negative, or neutral. Respond only with JSON: {"sentiment": "<label>"}'),
}

def evaluate_prompt(system_prompt):
    correct = 0
    for text, gold in labelled:
        reply = llm.chat([{"role": "system", "content": system_prompt},
                          {"role": "user", "content": f"Text: {text}"}])
        obj, _ = parse_json_output(reply.content or "")
        if obj and obj.get("sentiment") == gold:
            correct += 1
    return correct / len(labelled)

for name, system_prompt in prompt_versions.items():
    print(f"{name}: accuracy = {evaluate_prompt(system_prompt):.2f}")
'''),
    md("""
## Practices checklist

- State the role and the task in plain language.
- Specify the output format exactly, and validate it in code.
- Put constraints (length, allowed labels, what to avoid) in the prompt.
- Separate user content with clear delimiters so it cannot be confused with instructions.
- Add few-shot examples for the edge cases you care about most.
- Version prompts and measure each change on a labelled set (notebook 05).
- Never put secrets in prompts. Assume the prompt can be extracted by a user.
"""),
]

# ---------------------------------------------------------------- 02
EMBEDDINGS = [
    md("""
# 02 · Embeddings and vector stores

An embedding maps text to a vector so that similar meanings land close together.
A vector store keeps those vectors and returns the nearest ones for a query.

The default embedder is lexical (shared words only), so it cannot match synonyms.
Set `EMBED_PROVIDER=openai` to use semantic embeddings and compare the results.
"""),
    code(SETUP + '''
from embeddings import get_embedder, cosine
from vector_store import InMemoryVectorStore

embed = get_embedder()
print("Embedder:", getattr(embed, "__name__", type(embed).__name__))
'''),
    md("## 1. Similarity between texts"),
    code('''
pairs = [
    ("The cat sat on the mat.", "A cat was sitting on a mat."),
    ("The cat sat on the mat.", "Quarterly revenue grew by twelve percent."),
    ("refund policy", "How do I get my money back?"),
]
for a, b in pairs:
    print(f"{cosine(embed(a), embed(b)):.3f}  |  {a!r}  vs  {b!r}")
'''),
    md("""
With the lexical embedder, the first pair scores high because the words overlap. The
last pair scores low even though the meaning is close. That gap is what semantic
embedding models close. Run this cell with `EMBED_PROVIDER=openai` to compare.
"""),
    md("## 2. Build an index and search it"),
    code('''
store = InMemoryVectorStore()
docs = {
    "doc-1": "Refunds are issued within 30 days with a receipt.",
    "doc-2": "Shipping takes three to five business days.",
    "doc-3": "Our support team answers email within one business day.",
    "doc-4": "Warranty covers manufacturing defects for one year.",
}
for doc_id, text in docs.items():
    store.add(doc_id, text, embed(text),
              metadata={"section": "shipping" if doc_id == "doc-2" else "policies"})
print("Items indexed:", len(store))

for hit in store.search(embed("how long does delivery take"), k=2):
    print(hit["score"], hit["id"], "-", hit["text"])
'''),
    md("## 3. Metadata filters narrow the search"),
    code('''
for hit in store.search(embed("policy"), k=3, where={"section": "policies"}):
    print(hit["score"], hit["id"], hit["metadata"])
'''),
    md("## 4. Save and reload the index"),
    code('''
import os, tempfile
path = os.path.join(tempfile.mkdtemp(), "index.json")
store.save(path)
reloaded = InMemoryVectorStore.load(path)
print("Reloaded items:", len(reloaded))
same_top = (reloaded.search(embed("refund"), k=1)[0]["id"]
            == store.search(embed("refund"), k=1)[0]["id"])
print("Same top hit after reload:", same_top)
'''),
    md("""
## Production notes

- Use the same embedding model for documents and queries. Changing the model means re-embedding everything.
- Store the chunk text and a source id in metadata, so answers can cite their sources.
- Real vector databases (FAISS, Chroma, pgvector, managed services) add approximate nearest-neighbour indexes, persistence, concurrency, and filtering at scale.
- Check whether your store expects normalized vectors when you use dot product versus cosine.
"""),
]

# ---------------------------------------------------------------- 03
RAG = [
    md("""
# 03 · Retrieval-augmented generation (RAG)

Pipeline: **chunk → embed → index → retrieve → build a prompt with the context → answer with citations**.

Evaluate retrieval and answers separately. A wrong answer can come from retrieval
(the right document was never retrieved) or from generation (the document was retrieved
but the answer misused it).
"""),
    code(SETUP + '''
from rag import RAGPipeline, chunk_text
from embeddings import get_embedder
from llm_utils import get_llm
from sample_data import DOCS, GOLD_RETRIEVAL
from evaluation import retrieval_metrics, doc_ids_from_chunks

print("Documents:", list(DOCS))
'''),
    md("## 1. Chunking"),
    code('''
sample = DOCS["refund_policy"]
for i, chunk in enumerate(chunk_text(sample, max_words=12, overlap=4)):
    print(i, "|", chunk)
'''),
    md("## 2. Index the documents"),
    code('''
pipeline = RAGPipeline(get_llm(), get_embedder(), k=2, max_words=40, overlap=10)
print("Chunks indexed:", pipeline.index(DOCS))
'''),
    md("## 3. Retrieval quality on a small gold set"),
    code('''
for question, relevant_doc in GOLD_RETRIEVAL:
    hits = pipeline.retrieve(question, k=4)
    ranked = doc_ids_from_chunks([h["id"] for h in hits])
    print(f"{question}\\n  ranked docs: {ranked}")
    print(f"  {retrieval_metrics(ranked, [relevant_doc], k=2)}\\n")
'''),
    md("## 4. Answers with citations"),
    code('''
for question in [
    "How long do refunds take?",
    "What does the warranty cover?",
    "Do you sell furniture?",
]:
    result = pipeline.answer(question)
    print("Q:", question)
    print("A:", result["answer"])
    print("Sources:", result["sources"], "\\n")
'''),
    md("""
The last question is not covered by the documents, so the system should say it does not know.
Test this behaviour across many out-of-scope questions before you trust it, because
models often answer from general knowledge when the context is thin.
"""),
    md("## 5. Inspect exactly what the model received"),
    code('''
result = pipeline.answer("When can I call support by phone?")
for m in result["messages"]:
    print(f"--- {m['role']} ---\\n{m['content']}\\n")
'''),
    md("""
## Tuning levers

- **Chunk size and overlap:** smaller chunks give precise matches; larger chunks keep context. Overlap protects facts that straddle a boundary.
- **k:** more chunks raise recall but add noise and cost.
- **Embedding model:** semantic models usually beat lexical ones for paraphrased questions.
- **Metadata filters:** restrict by product, date, or access level before ranking.
- **Reranking and hybrid search:** combine keyword and vector scores, then rerank the top results with a stronger model.
- **Prompt instructions:** require citations and abstention, and test both.

Change one lever at a time and re-run the evaluation in notebook 05.
"""),
]

# ---------------------------------------------------------------- 04
TOOLS = [
    md("""
# 04 · Function (tool) calling

The model proposes a tool call with JSON arguments. Your code validates the arguments,
runs the function, and returns the result. **The model never executes code itself.**
"""),
    code(SETUP + '''
from tools import Tool, ToolRegistry, get_weather, safe_eval, run_tool_loop
from llm_utils import get_llm

registry = ToolRegistry()
registry.register(Tool(
    name="get_weather",
    description="Get the current weather forecast for a city.",
    parameters={"type": "object",
                "properties": {"city": {"type": "string", "description": "City name"}},
                "required": ["city"]},
    fn=get_weather,
))
registry.register(Tool(
    name="calculator",
    description="Evaluate an arithmetic expression using + - * / and parentheses.",
    parameters={"type": "object",
                "properties": {"expression": {"type": "string"}},
                "required": ["expression"]},
    fn=lambda expression: {"result": safe_eval(expression)},
))
print([s["function"]["name"] for s in registry.schemas()])
'''),
    md("## 1. Validation happens before anything runs"),
    code('''
print(registry.dispatch("get_weather", '{"city": "Paris"}'))
print(registry.dispatch("get_weather", '{}'))
print(registry.dispatch("get_weather", '{"city": "Paris", "units": "C"}'))
print(registry.dispatch("calculator", '{"expression": "10 / 0"}'))
print(registry.dispatch("delete_files", '{}'))
print(registry.dispatch("calculator", 'not json'))
'''),
    md("## 2. Safe expression evaluation (no `eval`)"),
    code('''
print(safe_eval("2 * (3 + 4) - 5 / 2"))
try:
    safe_eval("__import__('os').system('echo unsafe')")
except ValueError as e:
    print("Rejected:", e)
'''),
    md("## 3. The tool loop"),
    code('''
for question in ["What is the weather in Paris?", "What is 12 * (3 + 4)?"]:
    out = run_tool_loop(get_llm(), registry, question)
    print("Q:", question)
    print("Trace:", out["trace"])
    print("A:", out["answer"], "\\n")
'''),
    md("""
Tool results go back into the conversation as `tool` messages, and the model writes the
final answer from them. The step limit stops a confused model from looping forever.
Try a question that needs no tool, and confirm the loop returns without calling one.
"""),
    md("""
## Production checklist

- Validate every argument against the schema, and reject unexpected fields.
- Allowlist which tools each user or role may call.
- Give tools least-privilege credentials.
- Require human confirmation for actions with side effects (payments, deletions, sending messages).
- Time out and rate-limit tool calls.
- Return errors to the model in a structured form so it can recover.
- Log every call with arguments and results, minus sensitive data.
- Treat tool output as untrusted input. Web pages and documents can contain instructions aimed at the model (prompt injection).
"""),
]

# ---------------------------------------------------------------- 05
EVALUATION = [
    md("""
# 05 · Evaluation frameworks

An evaluation has five parts: test cases, metric functions, a runner, aggregate
summaries, and thresholds that gate a release. This notebook builds each part without
external dependencies, so you can see what the frameworks do internally.
"""),
    code(SETUP + '''
from evaluation import (keyword_recall, groundedness, retrieval_metrics,
                        doc_ids_from_chunks, run_eval, score_from_judge)
from rag import RAGPipeline
from embeddings import get_embedder
from llm_utils import get_llm
from sample_data import DOCS, QA_CASES

pipeline = RAGPipeline(get_llm(), get_embedder(), k=2)
pipeline.index(DOCS)
print("Cases:", len(QA_CASES))
'''),
    md("""
## 1. Metrics

Each metric takes a case and the system's result. Returning `None` means the metric
does not apply to that case, and it is left out of the average.
"""),
    code('''
def answer_keywords(case, result):
    if case["expect_abstain"]:
        return None
    return keyword_recall(result["answer"] or "", case["keywords"])

def abstained(case, result):
    if not case["expect_abstain"]:
        return None
    return 1.0 if (result["answer"] or "").lower().startswith("i don't know") else 0.0

def retrieval_mrr(case, result):
    if case["relevant_doc"] is None:
        return None
    ranked = doc_ids_from_chunks(result["sources"])
    return retrieval_metrics(ranked, [case["relevant_doc"]], k=max(len(ranked), 1))["mrr"]

def grounded(case, result):
    if case["expect_abstain"]:
        return None
    return groundedness(result["answer"] or "", result["context"])

METRICS = {
    "answer_keywords": answer_keywords,
    "abstained": abstained,
    "retrieval_mrr": retrieval_mrr,
    "groundedness": grounded,
}
'''),
    md("## 2. Run the suite"),
    code('''
def system_under_test(question):
    return pipeline.answer(question)

report = run_eval(QA_CASES, system_under_test, METRICS)
for row in report["rows"]:
    print(row)
print("\\nSummary:", report["summary"])
'''),
    md("""
## 3. Gate the release on thresholds

These thresholds are placeholders. Set them from a baseline measured on your own data,
and keep them in version control next to the test cases.
"""),
    code('''
THRESHOLDS = {"answer_keywords": 0.8, "abstained": 1.0, "retrieval_mrr": 0.5}

gate_failures = []
for name, minimum in THRESHOLDS.items():
    value = report["summary"].get(name)
    if value is None or value < minimum:
        gate_failures.append((name, value, minimum))

print("Gate:", "PASS" if not gate_failures else "FAIL")
for name, value, minimum in gate_failures:
    print(f"  {name}: {value} (required >= {minimum})")
'''),
    md("""
## 4. LLM-as-judge

A judge model scores answers against a rubric. It scales better than human review, but
it must be validated against human labels first, because it can be inconsistent or biased.

The offline mock cannot judge, so this section shows the plumbing with a simulated reply.
Call `judge_groundedness` only when `LLM_PROVIDER=openai` is set.
"""),
    code('''
RUBRIC = ("Rate how well the answer is supported by the context on a 1-5 scale. "
          "5 = every claim is supported; 1 = unsupported. Reply with the number first.")

def judge_groundedness(case, result):
    if case["expect_abstain"]:
        return None
    messages = [
        {"role": "system", "content": RUBRIC},
        {"role": "user", "content": (f"Context:\\n{result['context']}\\n\\n"
                                     f"Question: {case['question']}\\nAnswer: {result['answer']}")},
    ]
    reply = get_llm().chat(messages).content or ""
    return score_from_judge(reply)

simulated_reply = "4 - Most claims are supported by the refund policy context."
print("Parsed judge score:", score_from_judge(simulated_reply))
'''),
    md("""
## 5. Where this goes next

- **Regression suite:** every production bug becomes a permanent case, tagged with its origin.
- **Run on every change:** prompts, models, chunking, and indexes all need the same suite.
- **Judge calibration:** measure agreement between the judge and human reviewers, and re-check it when the judge model changes.
- **Frameworks:** Ragas (RAG metrics), DeepEval, promptfoo (prompt and model comparisons), and TruLens cover much of this with more metrics and dashboards. Use them once you understand the parts above, so you can check what they report.
- **Production monitoring:** apply the same rule-based metrics to sampled live traffic, and track thumbs-down rates and refusal rates over time (see the evaluation guide).
"""),
]

NOTEBOOKS = {
    "01_prompt_engineering.ipynb": PROMPT_ENGINEERING,
    "02_embeddings_and_vector_stores.ipynb": EMBEDDINGS,
    "03_retrieval_augmented_generation.ipynb": RAG,
    "04_function_tool_calling.ipynb": TOOLS,
    "05_evaluation_frameworks.ipynb": EVALUATION,
}


def main():
    OUT.mkdir(exist_ok=True)
    for name, cells in NOTEBOOKS.items():
        path = OUT / name
        with open(path, "w", encoding="utf-8") as f:
            json.dump(notebook(cells), f, indent=1, ensure_ascii=False)
            f.write("\n")
        print("wrote", path)


if __name__ == "__main__":
    main()

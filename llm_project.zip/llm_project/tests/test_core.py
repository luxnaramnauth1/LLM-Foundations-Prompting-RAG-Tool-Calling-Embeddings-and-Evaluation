"""Tests for the core modules. Run with: pytest -q   (or: python tests/test_core.py)"""
import json
import os
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from embeddings import cosine, hashed_embedding  # noqa: E402
from evaluation import retrieval_metrics, score_from_judge  # noqa: E402
from llm_utils import MockLLM, tokenize  # noqa: E402
from prompting import PromptTemplate, parse_json_output, validate_keys  # noqa: E402
from rag import RAGPipeline, chunk_text  # noqa: E402
from sample_data import DOCS  # noqa: E402
from embeddings import get_embedder  # noqa: E402
from tools import Tool, ToolRegistry, default_registry, run_tool_loop, safe_eval  # noqa: E402
from vector_store import InMemoryVectorStore  # noqa: E402


def test_tokenize():
    assert tokenize("Hello, World 2!") == ["hello", "world", "2"]


def test_chunk_text_windows_overlap():
    chunks = chunk_text("a b c d e f", max_words=4, overlap=2)
    assert chunks == ["a b c d", "c d e f"]


def test_chunk_text_rejects_bad_overlap():
    try:
        chunk_text("a b c", max_words=2, overlap=2)
    except ValueError:
        return
    raise AssertionError("expected ValueError")


def test_cosine_identity_and_orthogonal():
    v = hashed_embedding("refund policy")
    assert abs(cosine(v, v) - 1.0) < 1e-9
    assert abs(cosine([1.0, 0.0], [0.0, 1.0])) < 1e-9


def test_safe_eval_arithmetic_and_rejection():
    assert safe_eval("2*(3+4)") == 14
    try:
        safe_eval("__import__('os')")
    except ValueError:
        return
    raise AssertionError("expected ValueError for a function call")


def test_registry_validation():
    reg = default_registry()
    assert json.loads(reg.dispatch("get_weather", '{"city": "Paris"}'))["city"] == "Paris"
    assert "missing" in json.loads(reg.dispatch("get_weather", "{}"))["error"]
    assert "unexpected" in json.loads(reg.dispatch("get_weather", '{"city": "X", "units": "C"}'))["error"]
    assert "unknown tool" in json.loads(reg.dispatch("nope", "{}"))["error"]
    assert "invalid JSON" in json.loads(reg.dispatch("calculator", "not json"))["error"]
    assert "ZeroDivisionError" in json.loads(reg.dispatch("calculator", '{"expression": "1/0"}'))["error"]


def test_tool_loop_uses_calculator():
    out = run_tool_loop(MockLLM(), default_registry(), "What is 12 * (3 + 4)?")
    assert out["trace"][0]["tool"] == "calculator"
    assert "84" in out["answer"]


def test_vector_store_search_filter_and_roundtrip():
    store = InMemoryVectorStore()
    store.add("a", "refund policy", hashed_embedding("refund policy"), {"kind": "policy"})
    store.add("b", "shipping times", hashed_embedding("shipping times"), {"kind": "logistics"})
    top = store.search(hashed_embedding("refund"), k=1)[0]
    assert top["id"] == "a"
    assert store.search(hashed_embedding("refund"), k=5, where={"kind": "logistics"})[0]["id"] == "b"
    with tempfile.TemporaryDirectory() as d:
        path = os.path.join(d, "idx.json")
        store.save(path)
        assert len(InMemoryVectorStore.load(path)) == 2


def test_rag_abstains_when_context_lacks_answer():
    pipeline = RAGPipeline(MockLLM(), get_embedder(), k=2)
    pipeline.index(DOCS)
    out = pipeline.answer("Do you sell furniture?")
    assert out["answer"].lower().startswith("i don't know")


def test_rag_cites_a_source():
    pipeline = RAGPipeline(MockLLM(), get_embedder(), k=2)
    pipeline.index(DOCS)
    out = pipeline.answer("How long do refunds take?")
    assert "[" in out["answer"] and out["sources"]


def test_prompt_template_checks_variables():
    t = PromptTemplate("Hi {name}, you are a {role}.")
    assert t.variables == ["name", "role"]
    try:
        t.render(name="A")
    except KeyError:
        pass
    else:
        raise AssertionError("expected KeyError for missing variable")
    assert t.render(name="A", role="tester") == "Hi A, you are a tester."


def test_parse_json_handles_fences_and_errors():
    obj, err = parse_json_output('```json\n{"a": 1}\n```')
    assert obj == {"a": 1} and err is None
    obj, err = parse_json_output("not json at all")
    assert obj is None and err


def test_validate_keys():
    assert validate_keys({"a": 1}, ["a", "b"]) == ["b"]


def test_retrieval_metrics():
    m = retrieval_metrics(["a", "b", "c"], ["b"], k=2)
    assert m == {"recall@k": 1.0, "precision@k": 0.5, "mrr": 0.5}


def test_score_from_judge():
    assert score_from_judge("4 - mostly supported") == 4
    assert score_from_judge("no score here") is None


if __name__ == "__main__":
    tests = [v for k, v in dict(globals()).items() if k.startswith("test_")]
    for t in tests:
        t()
        print("ok", t.__name__)
    print(f"{len(tests)} tests passed")
